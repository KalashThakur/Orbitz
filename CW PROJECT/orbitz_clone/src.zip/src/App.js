import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import NationalParks from './components/NationalParks';
import F1 from './components/F1';
import Description from './components/Description';
import PlayStore from './components/PlayStore';
import Cart from './components/Cart';
import Checkout from './components/Checkout';


function App() {
  return (
    <div className="App">
      {/* <Home /> */}
      {/* <NationalParks /> */}
      {/* <F1 /> */}
      {/* <Description /> */}
      {/* <PlayStore /> */}
      {/* <Cart /> */}
      <Checkout />
    </div>
  );
}

export default App;
