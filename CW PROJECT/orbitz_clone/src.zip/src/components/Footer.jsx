import React from 'react';


const Footer = () => {
  return (
    <div >
        <div>
            <a href="https://www.expediagroup.com/home/default.aspx"><img src="https://a.travel-assets.com/globalcontrols-service/content/f285fb631b0a976202ef57611c7050e9ef5ca51a/images/EG_Wordmark_blue_RGB.svg" alt="" /></a>
        </div>
        <div>
            <div>About</div>
            <div>Jobs</div>
            <div>Newsroom</div>
            <div>Advertising</div>
        </div>
        <div></div>
        <div></div>
        <div></div>
    </div>
  )
}

export default Footer